# Kurulum Rehberi

## 1. Ana repo'yu oluştur
GitHub'da **`KULLANICI-ADIN.github.io`** adında repo aç (kullanıcı adınla
BİREBİR aynı olmalı). Public yap.

## 2. Bu dosyaları yükle
Bu klasördeki tüm dosyaları (KUTUPHANE-REPO-README.md ve bu dosya HARİÇ)
repo'nun ana dizinine yükle:

```
_config.yml
index.md
blog.md
iletisim.md
akademik-projeler.md
izlediklerim.md
okuduklarim.md
_layouts/default.html
assets/style.css
_posts/2026-07-11-ornek-yazi.md
```

En kolay yol: GitHub'da repo sayfasında "Add file > Upload files" ile
klasör yapısını koruyarak sürükle-bırak yapmak. Ya da git kullanıyorsan:

```bash
git clone https://github.com/KULLANICI-ADIN/KULLANICI-ADIN.github.io.git
cd KULLANICI-ADIN.github.io
# bu klasördeki dosyaları buraya kopyala
git add .
git commit -m "İlk site kurulumu"
git push
```

## 3. _config.yml'i doldur
Bu dosyadaki şu alanları KENDİ bilgilerinle değiştir:
- `url`, `github_username`
- `kutuphane_repo` (adım 5'te oluşturacağın repo)
- `substack_url`, `substack_feed`
- `formspree_id` (adım 4'te alacaksın)
- `social:` altındaki tüm linkler

## 4. Formspree kurulumu (iletişim formu için)
1. https://formspree.io adresine git, ücretsiz hesap aç.
2. "New Form" oluştur, e-postanı doğrula.
3. Sana verilen form ID'sini (örn: `xzbqrsty`) `_config.yml`'deki
   `formspree_id` alanına yapıştır.
4. Ücretsiz plan ayda 50 mesaj gönderimine izin veriyor, kişisel site
   için fazlasıyla yeterli.

## 5. "kutuphane" reposunu oluştur
`KUTUPHANE-REPO-README.md` dosyasındaki talimatları takip et. Özetle:
- Yeni repo aç: `kutuphane`
- `izledim` ve `okudum` label'larını oluştur
- Her film/kitap için issue aç

## 6. GitHub Pages'i aktif et
Ana repo'da: **Settings > Pages > Source: "Deploy from branch" > Branch: main / (root)**
Birkaç dakika içinde siten `https://KULLANICI-ADIN.github.io` adresinde
yayında olacak.

## 7. Kendi bilgilerini gir
- `index.md` → isim, unvan, hakkımda yazısı
- `akademik-projeler.md` → proje kartlarını kendi projelerinle değiştir
- `iletisim.md` → e-posta adresini güncelle
- `_posts/` → istersen kendi blog notlarını ekle (opsiyonel, Substack
  zaten otomatik çekiliyor)

## Değiştirmen gereken TÜM yerler (özet)
Arama yaparak şunları bulup değiştir:
- `KULLANICI-ADIN` → GitHub kullanıcı adın
- `SENIN-ADIN` → Substack kullanıcı adın
- `seninmail@ornek.com` → gerçek e-postan
- `Adın Soyadın` → gerçek adın
- Sosyal medya URL'leri (`_config.yml` içinde)

## Test etme
Lokal olarak test etmek istersen (Ruby kuruluysa):
```bash
gem install bundler jekyll
bundle init
bundle add jekyll
bundle exec jekyll serve
```
Sonra `http://localhost:4000` adresini aç. Zorunlu değil — GitHub'a
push ettiğinde otomatik build edip yayınlıyor, lokal test opsiyonel.
