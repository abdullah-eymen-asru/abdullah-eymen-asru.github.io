# "kutuphane" reposu nasıl kurulur?

Bu dosya senin ana portfolyo sitene değil, AYRI bir repo'ya ait talimattır.

## 1. Yeni repo oluştur
GitHub'da `kutuphane` adında YENİ bir repo aç (public olmalı, API'nin
anahtarsız çalışabilmesi için).

## 2. Label oluştur
Repo > Issues > Labels kısmından iki label oluştur:
- `izledim` (film/dizi issue'ları için)
- `okudum`  (kitap issue'ları için)

İstersen ek label'lar da ekleyebilirsin, örneğin türe göre:
`roman`, `bilim-kurgu`, `belgesel` gibi — bunlar tabloda otomatik
"Etiket" sütununda görünecek.

## 3. Yeni kayıt eklemek = yeni issue açmak
Her film/dizi/kitap için yeni bir Issue aç:

**Örnek - film için:**
- Başlık: `Interstellar (2014)`
- Label: `izledim`
- Açıklama (isteğe bağlı): kısa yorumun, puanın vs.

**Örnek - kitap için:**
- Başlık: `Sapiens - Yuval Noah Harari`
- Label: `okudum`
- Açıklama: notların

## 4. Otomatik güncelleme
Portfolyo sitendeki İzlediklerim / Okuduklarım sayfaları bu repo'daki
issue'ları GitHub API üzerinden canlı çekiyor. Yeni issue açtığın anda
(birkaç dakika içinde, tarayıcı cache'i temizlenince) sitede görünür.
Hiçbir ek işlem, deploy, ya da kod değişikliği gerekmez.

## Not: API rate limit
GitHub'ın kimliksiz (anahtarsız) API isteklerinde saatlik 60 istek limiti
var. Kişisel bir site için bu fazlasıyla yeterli. Eğer ileride sorun
yaşarsan bana haber ver, token tabanlı bir çözüme geçebiliriz.
